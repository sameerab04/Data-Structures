﻿* If there is more than one operation outside of a parenthesis, it does not work correctly. 
   * Ex: (2+3)*5+6 will return 55 instead of 31
      * But ((2+3)*5)+6 will return 31